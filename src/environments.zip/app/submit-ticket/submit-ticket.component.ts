import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-submit-ticket',
  templateUrl: './submit-ticket.component.html',
  styleUrls: ['./submit-ticket.component.scss']
})
export class SubmitTicketComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
