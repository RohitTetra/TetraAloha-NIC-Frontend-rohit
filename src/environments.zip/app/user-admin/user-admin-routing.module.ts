import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { UserAdminComponent } from './user-admin.component';

const routes: Routes = [
  {
    path:'user-admin',component:UserAdminComponent,
    children: [
      { path: 'dashboard', component: DashboardComponent},
      
  { path: 'my-ticket', loadChildren: () => import('../submit-ticket/submit-ticket.module').then(m => m.SubmitTicketModule) },
    ]
  },
  
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserAdminRoutingModule { }
