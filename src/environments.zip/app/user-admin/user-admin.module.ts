import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UserAdminRoutingModule } from './user-admin-routing.module';
import { UserAdminComponent } from './user-admin.component';
import { DashboardComponent } from './dashboard/dashboard.component';


@NgModule({
  declarations: [
    UserAdminComponent,
    DashboardComponent
  ],
  imports: [
    CommonModule,
    UserAdminRoutingModule
  ],
  schemas:[CUSTOM_ELEMENTS_SCHEMA]
})
export class UserAdminModule { }
